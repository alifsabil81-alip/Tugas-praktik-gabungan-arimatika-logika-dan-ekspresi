# Input
tugas = float(input("Nilai Tugas: "))
nilai_akhir = round((0.2 * 80) + (0.3 * 70) + (0.5 * 70), 2)
if nilai_akhir >= 85 and kehadiran >= 90 and nilai_akhir % 2 == 0:
    status = "LULUS DENGAN PREDIKAT"
elif nilai_akhir >= 75 and kehadiran >= 80:
    status = "LULUS"
else:
    status = "BELUM LULUS"
print("Nilai Akhir:", nilai_akhir)
print("Status:", status)
if nilai_akhir >= 85 and kehadiran >= 90 and nilai_akhir % 2 == 0:
    status = "LULUS DENGAN PREDIKAT"
